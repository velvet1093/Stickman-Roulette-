# Base main-outfit VN portraits

Ten standalone, neutral visual-novel portrait PNGs, one base pose in the main outfit per character. This is a base-pose set, not an expression sheet or an animation set. These assets are supplied for review; they are not wired into the game. Existing overworld sprites and game code are unchanged by this package.

All PNGs are byte-for-byte copies of their generated originals. Pixels, alpha, embedded metadata, and provenance chunks are preserved. The original files remain in the generation output directory.

| Character | File | Canvas | Bytes | Alpha range | Visible bounds (alpha ≥32) |
| --- | --- | --- | ---: | --- | --- |
| Nami | [`nami.png`](nami.png) | 1024 × 1536 | 1,554,147 | 0–254 | `249, 5, 799, 1530` |
| Aqua | [`aqua.png`](aqua.png) | 1024 × 1536 | 1,549,335 | 0–254 | `277, 9, 953, 1525` |
| Krul | [`krul.png`](krul.png) | 1024 × 1536 | 1,875,979 | 0–254 | `68, 4, 971, 1509` |
| Marin | [`marin.png`](marin.png) | 1024 × 1536 | 1,482,368 | 0–254 | `280, 4, 808, 1516` |
| Asuna | [`asuna.png`](asuna.png) | 1024 × 1536 | 1,726,080 | 0–254 | `237, 5, 880, 1520` |
| Kurumi | [`kurumi.png`](kurumi.png) | 1024 × 1536 | 1,479,557 | 0–254 | `166, 5, 864, 1526` |
| Zero Two | [`zerotwo.png`](zerotwo.png) | 1024 × 1536 | 1,451,972 | 0–254 | `249, 6, 876, 1527` |
| Rem | [`rem.png`](rem.png) | 1024 × 1536 | 1,423,998 | 0–254 | `219, 7, 814, 1523` |
| Frieren | [`frieren.png`](frieren.png) | 1024 × 1536 | 1,647,962 | 0–254 | `190, 21, 878, 1517` |
| Yumeko | [`yumeko.png`](yumeko.png) | 1024 × 1536 | 1,459,289 | 0–254 | `189, 6, 855, 1520` |

Bounds use `left, top, right, bottom`, with right and bottom exclusive. The table uses alpha ≥32 to exclude barely visible alpha haze. The manifest also includes bounds at alpha ≥1 and alpha ≥128, and exact per-side border-alpha counts and sums. No trimming, padding, scaling, alpha normalization, or other pixel edits were applied.

`manifest.json` records the exact dimensions, PNG properties, alpha counts, bounds, source filenames, byte lengths, and SHA-256 digests. The alpha counts distinguish transparent (`0`), partially transparent (`1–254`), and opaque (`255`) pixels. The source alpha ranges shown in the table are preserved.

Each PNG decodes successfully, every PNG chunk CRC is valid, and each packaged file matches its source bytes and SHA-256 digest. No runtime tests were needed for this asset-only package.

The companion `../vn-base-main-outfit.zip` contains this directory's ten PNGs, README, and manifest under `vn/`.
